package com.jikexueyuan.game2048;


	
	import java.text.Format;
	import java.text.SimpleDateFormat;
	import java.util.Date;
	import java.util.GregorianCalendar;

	import org.achartengine.ChartFactory;
	import org.achartengine.GraphicalView;
	import org.achartengine.chart.PointStyle;
	import org.achartengine.model.SeriesSelection;
	import org.achartengine.model.TimeSeries;
	import org.achartengine.model.XYMultipleSeriesDataset;
	import org.achartengine.renderer.XYMultipleSeriesRenderer;
	import org.achartengine.renderer.XYSeriesRenderer;

	import android.app.Activity;
	import android.graphics.Color;
	import android.os.Bundle;
	import android.view.Menu;
	import android.view.View;
	import android.widget.LinearLayout;
	import android.widget.Toast;

	public class TimeLine extends Activity {
		
		private GraphicalView mChart;	
		
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.timeline);        
	        openChart();        
	    }
	    
	    private void openChart(){    	
	    	
	    	int count = 7;
	    	Date[] dt = new Date[7];
	    	for(int i=0;i<count;i++){
	    		GregorianCalendar gc = new GregorianCalendar(2014, 06, i+25);
	    		dt[i] = gc.getTime();
	    	}
	    	
	    	int[] visits = { 20,25,27,21,28,35,10};
	    	int[] views = {22, 27, 29, 28, 32,36,15};
	    	int[] values = {29, 20, 34, 36, 30,38,13};
	    	int[] values1 = {19, 29, 32, 38, 32,40,20};
	    	
	    	// Creating TimeSeries for Visits
	    	TimeSeries visitsSeries = new TimeSeries("Left");    	
	    	
	    	// Creating TimeSeries for Views
	    	TimeSeries viewsSeries = new TimeSeries("Right"); 
	    	
	    	TimeSeries valuesSeries = new TimeSeries("Up");
	    	
	    	TimeSeries values1Series = new TimeSeries("Down");
	    	
	    	// Adding data to Visits and Views Series
	    	for(int i=0;i<dt.length;i++){
	    		visitsSeries.add(dt[i], visits[i]);
	    		viewsSeries.add(dt[i],views[i]);
	    		valuesSeries.add(dt[i],values[i]);
	    		values1Series.add(dt[i],values1[i]);
	    	}
	    	
	    	// Creating a dataset to hold each series
	    	XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
	    	
	    	// Adding Visits Series to the dataset
	    	dataset.addSeries(visitsSeries);
	    	
	    	// Adding Visits Series to dataset
	    	dataset.addSeries(viewsSeries);
	    	
	    	dataset.addSeries(valuesSeries);
	    	
	    	dataset.addSeries(values1Series);
	    	
	    	// Creating XYSeriesRenderer to customize visitsSeries  	
	    	XYSeriesRenderer visitsRenderer = new XYSeriesRenderer();
	    	visitsRenderer.setColor(Color.RED);
	    	visitsRenderer.setPointStyle(PointStyle.CIRCLE);
	    	visitsRenderer.setFillPoints(true);
	    	visitsRenderer.setLineWidth(2);
	    	visitsRenderer.setDisplayChartValues(true);
	    	
	    	
	    	// Creating XYSeriesRenderer to customize viewsSeries
	    	XYSeriesRenderer viewsRenderer = new XYSeriesRenderer();
	    	viewsRenderer.setColor(Color.BLUE);
	    	viewsRenderer.setPointStyle(PointStyle.CIRCLE);
	    	viewsRenderer.setFillPoints(true);
	    	viewsRenderer.setLineWidth(2);
	    	viewsRenderer.setDisplayChartValues(true);
	    	
	    	XYSeriesRenderer valuesRenderer = new XYSeriesRenderer();
	    	valuesRenderer.setColor(Color.GRAY);
	    	valuesRenderer.setPointStyle(PointStyle.CIRCLE);
	    	valuesRenderer.setFillPoints(true);
	    	valuesRenderer.setLineWidth(2);
	    	valuesRenderer.setDisplayChartValues(true);
	    	
	    	XYSeriesRenderer values1Renderer = new XYSeriesRenderer();
	    	visitsRenderer.setColor(Color.RED);
	    	visitsRenderer.setPointStyle(PointStyle.CIRCLE);
	    	visitsRenderer.setFillPoints(true);
	    	visitsRenderer.setLineWidth(2);
	    	visitsRenderer.setDisplayChartValues(true);
	    	
	    	
	    	// Creating a XYMultipleSeriesRenderer to customize the whole chart
	    	XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
	    	
	    	multiRenderer.setChartTitle("Visits vs Views Chart");
	    	multiRenderer.setXTitle("Days");
	    	multiRenderer.setYTitle("Count");
	    	multiRenderer.setZoomButtonsVisible(true);    	
	    	
	    	// Adding visitsRenderer and viewsRenderer to multipleRenderer
	    	// Note: The order of adding dataseries to dataset and renderers to multipleRenderer
	    	// should be same
	    	multiRenderer.addSeriesRenderer(visitsRenderer);
	    	multiRenderer.addSeriesRenderer(viewsRenderer);
	    	multiRenderer.addSeriesRenderer(valuesRenderer);
	    	multiRenderer.addSeriesRenderer(values1Renderer);
	    	
	    	// Getting a reference to LinearLayout of the MainActivity Layout
	    	LinearLayout chartContainer = (LinearLayout) findViewById(R.id.chart_container);
	    	
	   		// Creating a Time Chart
	   		mChart = (GraphicalView) ChartFactory.getTimeChartView(getBaseContext(), dataset, multiRenderer,"dd-MMM-yyyy");   		
	   		
	   		multiRenderer.setClickEnabled(true);
	     	multiRenderer.setSelectableBuffer(10);
	     	
	     	// Setting a click event listener for the graph
	     	mChart.setOnClickListener(new View.OnClickListener() {
	     		@Override
	     	    public void onClick(View v) {
	     			Format formatter = new SimpleDateFormat("dd-MMM-yyyy");
	     			
	     			SeriesSelection seriesSelection = mChart.getCurrentSeriesAndPoint();

	     			if (seriesSelection != null) {     				
	     				int seriesIndex = seriesSelection.getSeriesIndex();
	            	  	String selectedSeries="Left";
	            	  	if(seriesIndex==0)
	            	  		selectedSeries = "Right";
	            	  	else if(seriesIndex==1)
	            	  		selectedSeries = "Up";
	            	  	else if(seriesIndex==2)
	            	  		selectedSeries = "Down";
	            	  	else 
	            	  		selectedSeries = "Left";
	            	  	// Getting the clicked Date ( x value )
	          			long clickedDateSeconds = (long) seriesSelection.getXValue();
	          			Date clickedDate = new Date(clickedDateSeconds);
	          			String strDate = formatter.format(clickedDate);
	          			
	          			// Getting the y value 
	          			int amount = (int) seriesSelection.getValue();
	          			
	          			// Displaying Toast Message
	          			Toast.makeText(
	                	       getBaseContext(),
	                	       selectedSeries + " on "  + strDate + " : " + amount ,
	                	       Toast.LENGTH_SHORT).show();
	     			}
	     		}
	  	
	     	});
	     	
	   		// Adding the Line Chart to the LinearLayout
	    	chartContainer.addView(mChart);
	    }

	   
	}
	
	
	
