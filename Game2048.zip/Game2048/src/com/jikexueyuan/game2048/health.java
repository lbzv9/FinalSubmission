package com.jikexueyuan.game2048;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class health extends Activity{
	Button button;
	public int a = 50;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.health);
		
		button = (Button) findViewById(R.id.button1);
		
		 
		button.setOnClickListener(new OnClickListener() {
 
			@Override
			public void onClick(View arg0) {
				
				
				EditText editText = (EditText) findViewById(R.id.editText1);
				EditText editText1 = (EditText) findViewById(R.id.editText2);
				EditText editText2 = (EditText) findViewById(R.id.editText4);
				
				int i = Integer.parseInt(editText.getText().toString());
				int j = Integer.parseInt(editText1.getText().toString());
				int k = Integer.parseInt(editText2.getText().toString());
				
				
				// BMR VALUE
					int s = (14 * i)+(5*j)-(7*k)+66;
				//RMR VALUE
					int t = (10 * i)+(6 * j)-(5*k)+5;
					
					Toast.makeText(getBaseContext(), "You need to burn "+"\n"+(s-t-a)+"\n"+"more calaories to be fit", Toast.LENGTH_LONG).show();
				
				
 
			}
 
		});
	
	
	
	
}

}