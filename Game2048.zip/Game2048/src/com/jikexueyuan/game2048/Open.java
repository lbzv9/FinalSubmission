package com.jikexueyuan.game2048;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Open extends Activity{
	
	Button start,instructions,exit;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.open);
		
		//String leftgesture=GameView.getDefaults("leftvalue", context);
		//String upgesture=GameView.getDefaults("upvalue", context);
		//String rightgesture=GameView.getDefaults("rightvalue", context);
		
	//	String allgestures=leftgesture+"\t"+upgesture+"\t"+rightgesture;
		
		start = (Button) findViewById(R.id.start);
	//	Game  gm1 = new Game();
        // Defining click event listener for the button btn_chart
		start.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
				// TODO Auto-generated method stub
				

				Intent game = new Intent(Open.this,Game.class);
				startActivity(game);
				
				
				
			}
			 
			
			
 
		});
		
		//to call connection service
		startService(new Intent(this,ConnectionService.class));
		
		
		Intent game = new Intent(this,Game.class);
		startActivity(game);
		
		
		
		
		
	}
	
	
	
	
	
	

}
