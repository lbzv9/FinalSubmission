package com.jikexueyuan.game2048;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;




public class MainActivity extends Activity {
	
	GameView view;
	Button button,report,contact_us,getlocation;
	Context context=this;
	private double latitudeE51 = 39.034474;

	private double longitudeE51 =-94.580972;
	Game gml = new Game();
	int i=0,j=0,k=0,l=0;
	//String allgestures;
	
	public MainActivity() {
		mainActivity = this;
	}
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		tvScore = (TextView) findViewById(R.id.tvScore);
		//String leftgesture=GameView.getDefaults("leftvalue", context);
		//String upgesture=GameView.getDefaults("upvalue", context);
		//String rightgesture=GameView.getDefaults("rightvalue", context);
		
	//	String allgestures=leftgesture+"\t"+upgesture+"\t"+rightgesture;
		
		button = (Button) findViewById(R.id.button2);
		report = (Button) findViewById(R.id.button1);
		getlocation =(Button) findViewById(R.id.button3);
		contact_us=(Button) findViewById(R.id.button4);
	//	Game  gm1 = new Game();
        // Defining click event listener for the button btn_chart
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				/*String leftgesture=GameView.getDefaults("leftvalue", context);
				String upgesture=GameView.getDefaults("upvalue", context);
				String rightgesture=GameView.getDefaults("rightvalue", context);
				String downgesture=GameView.getDefaults("downvalue", context);
				
				if(leftgesture!=null)
				{
					i=1;
				}
				if(upgesture!=null)
				{
					j=1;
				}
				if(rightgesture!=null)
				{
					k=1;
				}
				if(downgesture!=null)
				{
					l=1;
				}
				//Integer i = Integer.valueOf(leftgesture);
				int gestures=i+j+k+l;
				String gesture = Integer.toString(gestures);
				//String s = String.valueOf(i);
				String allgestures=leftgesture+"\t"+rightgesture+"\t"+upgesture+"\t"+downgesture+"\t"+gesture;
				gml.gesturevalues(allgestures);
				System.out.println("Data saved in file");
				//System.out.println();*/
				
				startService(new Intent(MainActivity.this,ConnectionService.class));
				Intent report = new Intent(MainActivity.this,Game.class);
				startActivity(report);
				
			}
			 
			
			
 
		});
		
		
		report.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				String leftgesture=GameView.getDefaults("leftvalue", context);
				String upgesture=GameView.getDefaults("upvalue", context);
				String rightgesture=GameView.getDefaults("rightvalue", context);
				String downgesture=GameView.getDefaults("downvalue", context);
				
				if(leftgesture!=null)
				{
					i=1;
				}
				if(upgesture!=null)
				{
					j=1;
				}
				if(rightgesture!=null)
				{
					k=1;
				}
				if(downgesture!=null)
				{
					l=1;
				}
				
				
				//Integer i = Integer.valueOf(leftgesture);
				int gestures=i+j+k+l;
				String gesture = Integer.toString(gestures);
				//String s = String.valueOf(i);
				String allgestures=leftgesture+"\t"+rightgesture+"\t"+upgesture+"\t"+downgesture+"\t"+gesture;
				gml.gesturevalues(allgestures);
				System.out.println("Data saved in file");
				//System.out.println();
				
				//startService(new Intent(MainActivity.this,ConnectionService.class));
				Intent report = new Intent(MainActivity.this,Report.class);
				startActivity(report);
				
			}
			 
			
			
 
		});
		contact_us.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
		
				Intent intent = new Intent(Intent.ACTION_VIEW,

						Uri.parse("geo:0,0?q=" + (latitudeE51+","+ longitudeE51)));

						startActivity(intent);
				//startService(new Intent(MainActivity.this,ConnectionService.cl8ass));
				
			}
		
		});
		
		getlocation.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
		
				Intent intent = new Intent(Intent.ACTION_CALL);
				 intent.setData(Uri.parse("tel:5732891751"));
				 startActivity(intent);
				
				
				
				//startService(new Intent(MainActivity.this,ConnectionService.cl8ass));
				
				
			}
		
		});

		
		
		//to call connection service
	/*	startService(new Intent(this,ConnectionService.class));
		
		
		Intent game = new Intent(this,Game.class);
		startActivity(game);*/
		
		
		
		
		
	}
	
	
	


	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void clearScore(){
		score = 0;
		showScore();
	}
	
	public void showScore(){
		tvScore.setText(score+"");
	}
	
	public void addScore(int s){
		score+=s;
		showScore();
	}

	public int score = 0;
	public TextView tvScore;
	
	private static MainActivity mainActivity = null;
	
	public static MainActivity getMainActivity() {
		return mainActivity;
	}

}
