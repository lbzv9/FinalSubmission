/** Automatically generated file. DO NOT MODIFY */
package com.jikexueyuan.game2048;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}